#ifndef NITI_H_INCLUDED
#define NITI_H_INCLUDED

#include <vector>

#include "suma_vektora.h"

using namespace std;

// v - vektor čije elemente treba sumirati
// povratna vrednost - suma svih elemenata vektora, izračunata pokretanjem 2 niti (svaka treba da obradi jednu polovinu elemenata)
double sumiraj(vector<double> v) {
    // Implementirati ...
}

#endif // NITI_H_INCLUDED

/*
Napraviti konkurentni program koji pokreće više niti u petlji. Svakoj niti proslediti njen redni broj prilikom kreiranja i svaka nit treba da ispiše sopstveni redni broj u okviru tela niti.
*/

#include <iostream>

using namespace std;

int main()
{
    return 0;
}

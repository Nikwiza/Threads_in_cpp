/*
Napraviti konkurentni program u kom se u funkciji niti pravi veliki niz od 1.000.000.000.000 elemenata. Niz se pravi dinamički. Kreiranje niza zaštititi try - catch blokom. U okviru try catch bloka zaključati mutex pre pravljenja niza i otključati ga nakon pravljenja niza. 

Posmatrati ponašanje programa.

Nakon toga promeniti kod tako da se ne zaključava mutex eksplicitno, već da se koristi klasa unique_lock.
*/



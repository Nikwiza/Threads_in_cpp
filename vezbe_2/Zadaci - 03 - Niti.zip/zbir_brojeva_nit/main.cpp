/*
Napraviti program koji kreira jednu nit kojoj se prosleđuju dva cela broja a i b. U okviru niti sabrati brojeve i ispisati na ekran njihov zbir.
*/

#include <iostream>

using namespace std;

int main()
{
    return 0;
}

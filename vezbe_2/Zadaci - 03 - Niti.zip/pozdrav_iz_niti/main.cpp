/* 
Napraviti program koji kreira jednu nit i u okviru niti ispisuje proizvoljnu rečenicu.
*/

#include <iostream>

using namespace std;

int main()
{
    return 0;
}
